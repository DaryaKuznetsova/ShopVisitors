﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Курсовая_работа;

namespace ShopTests
{
    [TestClass]
    public class ShopTest
    {
        [TestMethod]
        public void SquareX_2_6returned()
        {
            int a = 2;
            int b = 6;
            int expected = 16;

            Shop s = new Shop();
            int actual = Shop.SquareX(a, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Attr_3_0()
        {
            int a = 3;
            int b = 0;
            double expected = 3;
;
            double actual = Shop.Attr(b, a);

            Assert.AreEqual(expected, actual);
        }

    }
}
