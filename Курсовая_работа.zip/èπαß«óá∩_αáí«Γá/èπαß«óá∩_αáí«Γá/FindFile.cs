﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Курсовая_работа
{
    public partial class FindFile : Form // Выбор записи в массив
    {
        public FindFile()
        {
            InitializeComponent();
            Image img = Properties.Resources.citymap;
            this.BackgroundImage = new Bitmap(img);
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Yes;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.No;
        }

        private void FindFile_Load(object sender, EventArgs e)
        {

        }
    }
}
