﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;


namespace Курсовая_работа
{

    public partial class Form1 : Form
    {
        public Shop[] arrOfShops = new Shop[0];              // Инициализация массива
        public bool customersCounted = false;                // Рассчитано ли количество посетителей
        public int addingCount = 0;                          // Счетчик добавляемых элементов
        public int startArrLength = 0;                       // Начальная длина массива
        public string fileName = "количество посетителей";   // Начальное имя охраняемого файла
        public bool UpdateInForm = false;                    // Внесение изменений в массив
        public bool exitFromBotton = false;                  // Выход по кнопке
        public int countForChange = 0;                       // Для управления видимостью кнопок
        public bool all = false;

        void BlockButtons(Form1 f, bool countEnabled, bool showEnabled, bool chahgeEnabled, bool addEnabled, bool delEnabled, bool sortEnabled, bool saveEnabled)
        {
            
            f.createButton.Enabled = countEnabled;
            f.showResultsButton.Enabled = showEnabled;
            f.changesButton.Enabled = chahgeEnabled;
            f.addInfoButton.Enabled = addEnabled;
            f.deleteInfoButton.Enabled = delEnabled;
            f.sortingButton.Enabled = sortEnabled;
            f.saveButton.Enabled = saveEnabled;
        }

        static void VisibleButtons(Form1 f,bool addV, bool delV, bool sortV, bool backV, bool groupV)
        {
            f.addInfoButton.Visible = addV;
            f.deleteInfoButton.Visible = delV;
            f.sortingButton.Visible = sortV;
            f.showingB.Visible = backV;
            f.groupBox1.Visible = groupV;
        }

        static bool SavingIntoFile(ref string filename) // Выбор пути сохранения и проверка расширения
        {
            bool ok = false;
            SaveFileDialog SFD = new SaveFileDialog();
            SFD.Filter = "Файлы Excel|*.xlsx;*.xls";
            if (SFD.ShowDialog() == DialogResult.Cancel)
                return false;
            
            filename = SFD.FileName;
            string sss = "";
            string ssss = "";
            if (filename.Length >= 3)
            {
                sss = filename.Substring(filename.Length - 3);
                ssss = filename.Substring(filename.Length - 4);
            }
            if (sss != "xls" && ssss != "xlsx")
            {
                MessageBox.Show("Неверное расширение");
                ok = false;
            }
            else ok = true;
            return ok;
        }

        public Form1()
        {
            InitializeComponent();
            Image img = Properties.Resources.map;
            this.BackgroundImage = new Bitmap(img);
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void createButton_Click(object sender, EventArgs e)
        {
            Shop.CountVisitors(arrOfShops);
            BlockButtons(this, true, true, true, true, true, true, true);
            customersCounted = true;
            UpdateInForm = true;
            MessageBox.Show("Количество посетителей посчитано!");
        }

        private void addInfoButton_Click(object sendre, EventArgs e)
        {
            AddInfo add = new AddInfo();
            VisibleAd(add, true);
            add.idxT.Text = Convert.ToString(startArrLength +addingCount + 1);
            if (add.ShowDialog() == DialogResult.OK)
            {
                Shop s = new Shop();

                if (add.xT.Text.Length > 0 && add.yT.Text.Length > 0 && add.numberT.Text.Length > 0 && add.comboBox1.Text.Length > 0)
                {
                    try
                    {
                        addingCount++; // Увеличиваем индекс нового добавленного магазина

                        s = new Shop(startArrLength+addingCount, Convert.ToInt32(add.xT.Text), Convert.ToInt32(add.yT.Text), Convert.ToDouble(add.numberT.Text), Convert.ToInt32(add.comboBox1.Text), add.nameT.Text);
                        arrOfShops = Shop.AddShop(arrOfShops, s);

                        customersCounted = false; // Внесли изменения - нужно пересчитать количество посетителей
                        UpdateInForm = true;
                        BlockButtons(this,true, false, true, true, true, false, true);
                        MessageBox.Show("Запись добавлена!");
                    }
                    catch(Exception)
                    {
                        MessageBox.Show("Похоже, на даннй момент нет информации ни об одном магазине. Единственный экземпляр создан.");
                        arrOfShops[0] = s;
                    }
                }
                else MessageBox.Show("Необходимо заполнить все поля.");  
            }
        }

        private void deleteInfoButton_Click(object sender, EventArgs e)
        {
            all = true;
            if (arrOfShops.Length > 0)
            {
                bool ok = false;
                ShowShops ss = new ShowShops();
                ss.Owner = this;
                ss.button2.Visible = false;
                int n = 0;
                ss.label2.Text = "Выберите магазин для удаления";
                if (ss.ShowDialog() == DialogResult.OK)
                {
                    n = Convert.ToInt32(ss.textBox1.Text);
                    if (n > 0)
                    {
                        arrOfShops = Shop.DeleteShop(ref arrOfShops, n, ref ok);

                        customersCounted = false; // Внесли изменения - нужно пересчитать количество посетителей
                        BlockButtons(this, true, false, true, true, true, false, true);
                        UpdateInForm = true;
                        if (ok)
                            MessageBox.Show("Запись удалена!");
                        else MessageBox.Show("Запись не удалена.");
                    }
                    else MessageBox.Show("Индекс не может быть меньше единицы.");
                }
            }
            else MessageBox.Show("Список магазинов пуст");
            
        }

        private void showResultsButton_Click(object sender, EventArgs e)
        {
            all = false;
            if (arrOfShops.Length > 0)
            {
                ShowShops ss = new ShowShops();
                ss.Owner = this;
                if (customersCounted)
                    ss.label2.Text = "Ожидаемое количество посетителей магазина";

                ss.label1.Visible = false; //Скрыли элементы, отображаемые при удалении
                ss.textBox1.Visible = false;
                ss.button1.Visible = false;
                ss.Show();
            }
            else MessageBox.Show("Список магазинов пуст");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            VisibleButtons(this,false, false, false, false, false);
            BlockButtons(this,false, false, false, false, false, false, false);
        } 

        private void saveButton_Click(object sender, EventArgs e)
        {
            bool saved = true;
            AskForCounting(customersCounted, ref arrOfShops); // Если посетители не посчитаны, показать окно с вопросом
            bool save = SavingIntoFile(ref fileName); // Название и путь файла выбраны успешно
            if(save)
            {
                XlsWork.SaveChanges(arrOfShops, fileName, ref saved);
                if (saved)
                {
                    MessageBox.Show("Изменения сохранены!");
                    UpdateInForm = false;
                }
                else MessageBox.Show("Изменения не сохранены. Убедитесь, что доступ к данному файлу открыт, а само приложение закрыто.");
            }
            

        }

        private void settingsButton_Click(object sender, EventArgs e)
        {
           

        }

        private void sortingButton_Click(object sender, EventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show(
        "Отсортировать список магазинов по возрастанию количества посетителей?",
        "Сообщение", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Shop.quicksort(arrOfShops, 0, arrOfShops.Length - 1);
                MessageBox.Show("Отсортировали по возрастанию!");
            }
            if (result == DialogResult.No)
            {
                Shop.quicksort(arrOfShops, 0, arrOfShops.Length - 1);
                Array.Reverse(arrOfShops);
                MessageBox.Show("Отсортировали по убыванию!");
            }
            
            UpdateInForm = true; // Вносили изменения, их нужно сохранить
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            bool forbid = false;
            bool fileChosen = false;
            FindFile ff = new FindFile();
            if (ff.ShowDialog()==DialogResult.Yes)
            {
                OpenFileDialog OPF = new OpenFileDialog();
                OPF.Filter = "Файлы Excel|*.xls;*.xlsx";
                if (OPF.ShowDialog() == DialogResult.OK)
                {
                    fileName = OPF.FileName;
                    OpenFileSupport(ref arrOfShops, fileName, ref forbid, ref startArrLength); // Проверить, открывается ли файл
                    fileChosen = true;
                }
            }
            else
            if (ff.DialogResult== DialogResult.No)
            {
                DialogResult result;
                result = MessageBox.Show(
            "Внести новые данные о магазинах?",
            "Сообщение", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    startArrLength = 0;
                    AddInfo ad = new AddInfo();

                    VisibleAd(ad, false);

                    if (ad.ShowDialog() == DialogResult.OK && ad.shopsNumber.Text.Length > 0)
                    {
                        int n = Convert.ToInt32(ad.shopsNumber.Text);
                        arrOfShops = UserArray(n);
                        MessageBox.Show("Новый список магазинов создан");
                    }
                }
                if (result == DialogResult.No)
                {
                    Shop.CreateShops(ref arrOfShops);
                    MessageBox.Show("Стандартный список магазинов создан");
                }
                fileChosen = true;
            }
            startArrLength = arrOfShops.Length;

            if (forbid)
            {
                BlockButtons(this,false, false, false, false, false, false, false);
            }
            else
            {
                if(fileChosen)
                BlockButtons(this,true, false, true, true, true, false, true);
            }
        }

        static Shop[] UserArray(int n)
        {
            int i = 0;
            bool allFields = false;
            Shop[] arr = new Shop[n];
            while(i < n)
            {
                int count = i + 1;
                arr[i] = new Shop();
                AddInfo ad = new AddInfo();

                VisibleAd(ad, true);
                ad.idxT.Text = $"{count}/{n}";

                do
                { 
                    if (ad.ShowDialog() == DialogResult.OK)
                    {
                        Shop s = new Shop();
                    
                        if (ad.xT.Text.Length > 0 && ad.yT.Text.Length > 0 && ad.numberT.Text.Length > 0 && ad.comboBox1.Text.Length > 0)
                        {
                            try
                            {
                                s = new Shop(count, Convert.ToInt32(ad.xT.Text), Convert.ToInt32(ad.yT.Text), Convert.ToDouble(ad.numberT.Text), Convert.ToInt32(ad.comboBox1.Text), ad.nameT.Text);
                                arr[i] = s;
                            }
                            catch (Exception)
                            {
                                MessageBox.Show("Что-то пошло не так");
                            }
                            allFields = true;
                            i++;
                        }
                        else
                        {
                            MessageBox.Show("Необходимо заполнить все поля.");
                        }
                        
                    }
                } while (!allFields);
               
            }
            return arr;
        }

        static void VisibleAd(AddInfo ad, bool gatherInfo)
        {
            if (gatherInfo)
            {
                ad.numberOfShops.Visible = false;
                ad.shopsNumber.Visible = false;
                ad.createNewList.Visible = false;
                ad.idxT.ReadOnly = true;
            }
            else
            {
                ad.idxLabel.Visible = false;
                ad.idxT.Visible = false;
                ad.label1.Visible = false;
                ad.label2.Visible = false;
                ad.label3.Visible = false;
                ad.label4.Visible = false;
                ad.xT.Visible = false;
                ad.yT.Visible = false;
                ad.numberT.Visible = false;
                ad.comboBox1.Visible = false;
                ad.button1.Visible = false;
                ad.nameL.Visible = false;
                ad.nameT.Visible = false;
            }
        }

        static void OpenFileSupport(ref Shop[]arrOfShops, string fileName, ref bool forbid, ref int startArrLength)
        {
                XlsWork.CorrectArraysUsingExcel(ref arrOfShops, fileName, ref forbid); // Попытаться прочитать данные из файла
                if(!forbid) // Удачное чтение
                MessageBox.Show("Данные записаны!");
            
            else
            {
                DialogResult result;
                result = MessageBox.Show(
            "Данные в файле могли быть некорректны. Создать новый список магазинов?",
            "Сообщение", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    Shop.CreateShops(ref arrOfShops);
                    MessageBox.Show("Данные записаны!");
                    forbid = false;
                }
                if (result == DialogResult.No)
                {
                    MessageBox.Show("Проверьте, одинаковое ли количество элементов содержиться в каждом столбце и во всех ли ячейках содержтся числа.");
                    forbid = true;
                }
            }
            startArrLength = arrOfShops.Length;
  
        }

        private void Form1_FormClosing_1(object sender, FormClosingEventArgs e)
        {
            bool saved = true;
            bool ok = false;
            if (UpdateInForm) // Если вносили изменения
            {
                
                DialogResult result = MessageBox.Show("Сохранить изменения в файл перед выходом?", "Внимание", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    AskForCounting(customersCounted, ref arrOfShops); // Если не посчитали посетителей
                    bool save = SavingIntoFile(ref fileName);
                    if (save)
                    {
                        XlsWork.SaveChanges(arrOfShops, fileName, ref saved);
                        if(saved)
                        MessageBox.Show("Изменения сохранены!");
                        else MessageBox.Show("Изменения не сохранены. Убедитесь, что доступ к данному файлу открыт, а само приложение закрыто.");

                    } 
                }
                else if (result == System.Windows.Forms.DialogResult.No)
                {
                    // Ничего не сохраняем
                }
                else e.Cancel = true; //Отменяем действие
            }
        }

        static void AskForCounting(bool countedVisitors, ref Shop [] arr) // Проверка, нужно ли считать посетителей
        {
            if(!countedVisitors)
            {
                DialogResult result = MessageBox.Show("Расчитать количество посетителей перед сохранением?", "Внимание", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == System.Windows.Forms.DialogResult.Yes)
                    Shop.CountVisitors(arr);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
                Close();
        }

        private void changesButton_Click(object sender, EventArgs e)
        {
            if (countForChange % 2 == 0)
                VisibleButtons(this, true, true, true, true, true);  
            else
                VisibleButtons(this, false, false, false, false, false);
            countForChange++;
        }

        private void showingB_Click(object sender, EventArgs e)
        {
            VisibleButtons(this,false, false, false, false, false);
            countForChange++;
        }

        private void startButton_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Left)
            //{
            //    createButton.Focus();
            //}
        }

        private void createButton_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Left)
            //{
            //    showResultsButton.Focus();
            //}
        }
    }
}
