﻿namespace Курсовая_работа
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.createButton = new System.Windows.Forms.Button();
            this.addInfoButton = new System.Windows.Forms.Button();
            this.deleteInfoButton = new System.Windows.Forms.Button();
            this.showResultsButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.sortingButton = new System.Windows.Forms.Button();
            this.startButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.changesButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.showingB = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // createButton
            // 
            this.createButton.Location = new System.Drawing.Point(87, 108);
            this.createButton.Name = "createButton";
            this.createButton.Size = new System.Drawing.Size(200, 60);
            this.createButton.TabIndex = 0;
            this.createButton.Text = "Расчитать количество посетителей магазина\r\n";
            this.createButton.UseVisualStyleBackColor = true;
            this.createButton.Click += new System.EventHandler(this.createButton_Click);
            this.createButton.KeyDown += new System.Windows.Forms.KeyEventHandler(this.createButton_KeyDown);
            // 
            // addInfoButton
            // 
            this.addInfoButton.Location = new System.Drawing.Point(6, 36);
            this.addInfoButton.Name = "addInfoButton";
            this.addInfoButton.Size = new System.Drawing.Size(200, 60);
            this.addInfoButton.TabIndex = 1;
            this.addInfoButton.Text = "Добавить информацию о магазине";
            this.addInfoButton.UseVisualStyleBackColor = true;
            this.addInfoButton.Click += new System.EventHandler(this.addInfoButton_Click);
            // 
            // deleteInfoButton
            // 
            this.deleteInfoButton.Location = new System.Drawing.Point(5, 102);
            this.deleteInfoButton.Name = "deleteInfoButton";
            this.deleteInfoButton.Size = new System.Drawing.Size(200, 60);
            this.deleteInfoButton.TabIndex = 2;
            this.deleteInfoButton.Text = "Удалить информацию о магазине";
            this.deleteInfoButton.UseVisualStyleBackColor = true;
            this.deleteInfoButton.Click += new System.EventHandler(this.deleteInfoButton_Click);
            // 
            // showResultsButton
            // 
            this.showResultsButton.Location = new System.Drawing.Point(87, 174);
            this.showResultsButton.Name = "showResultsButton";
            this.showResultsButton.Size = new System.Drawing.Size(200, 60);
            this.showResultsButton.TabIndex = 3;
            this.showResultsButton.Text = "Посмотреть результаты";
            this.showResultsButton.UseVisualStyleBackColor = true;
            this.showResultsButton.Click += new System.EventHandler(this.showResultsButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(87, 307);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(200, 60);
            this.saveButton.TabIndex = 5;
            this.saveButton.Text = "Сохранить изменения";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // sortingButton
            // 
            this.sortingButton.Location = new System.Drawing.Point(6, 168);
            this.sortingButton.Name = "sortingButton";
            this.sortingButton.Size = new System.Drawing.Size(200, 60);
            this.sortingButton.TabIndex = 6;
            this.sortingButton.Text = "Отсортировать данные";
            this.sortingButton.UseVisualStyleBackColor = true;
            this.sortingButton.Click += new System.EventHandler(this.sortingButton_Click);
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(87, 42);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(200, 60);
            this.startButton.TabIndex = 7;
            this.startButton.Text = "Создать список магазинов";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            this.startButton.KeyDown += new System.Windows.Forms.KeyEventHandler(this.startButton_KeyDown);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(87, 452);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(200, 40);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Выход";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // changesButton
            // 
            this.changesButton.Location = new System.Drawing.Point(87, 241);
            this.changesButton.Name = "changesButton";
            this.changesButton.Size = new System.Drawing.Size(200, 60);
            this.changesButton.TabIndex = 9;
            this.changesButton.Text = "Внести изменения";
            this.changesButton.UseVisualStyleBackColor = true;
            this.changesButton.Click += new System.EventHandler(this.changesButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.showingB);
            this.groupBox1.Controls.Add(this.addInfoButton);
            this.groupBox1.Controls.Add(this.deleteInfoButton);
            this.groupBox1.Controls.Add(this.sortingButton);
            this.groupBox1.Location = new System.Drawing.Point(316, 100);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(211, 267);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Изменить";
            // 
            // showingB
            // 
            this.showingB.Location = new System.Drawing.Point(7, 235);
            this.showingB.Name = "showingB";
            this.showingB.Size = new System.Drawing.Size(75, 25);
            this.showingB.TabIndex = 7;
            this.showingB.Text = "Скрыть";
            this.showingB.UseVisualStyleBackColor = true;
            this.showingB.Click += new System.EventHandler(this.showingB_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 528);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.changesButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.showResultsButton);
            this.Controls.Add(this.createButton);
            this.Name = "Form1";
            this.Text = "Расчет ожидаемого количества посетителей магазина";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing_1);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        public System.Windows.Forms.Button createButton;
        public System.Windows.Forms.Button addInfoButton;
        public System.Windows.Forms.Button deleteInfoButton;
        public System.Windows.Forms.Button showResultsButton;
        public System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button sortingButton;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button changesButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button showingB;
    }
}

