﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Курсовая_работа
{
   public class Shop
    {
       public  int idx;
       public  int x;
       public  int y;
       public  double people;
       public  int quality;
       public  int visitors;
       public string name;

        public int Idx
        {
            get { return idx; }
            set
            {
                if (value >= 0) idx = value;
                else
                {
                    idx = 0;
                }
            }
        }

        public int Xc
        {
            get { return x; }
            set
            {

                if (value >= 10000)
                {
                    x = 10000;
                }
                else
                if (value < -10000)
                {
                    x = -10000;
                }
                else
                {
                    x = value;
                }
            }
        }

        public int Yc
        {
            get { return y; }
            set
            {

                if (value >= 10000)
                {
                    y = 10000;
                }
                else
                if (value < -10000)
                {
                    y = -10000;
                }
                else
                {
                    y = value;
                }
            }
        }

        public int Visitors
        {
            get { return visitors; }
            set
            {

                if (value >= 99999)             // Ограничение на количество жителей
                {
                    visitors = 99999;
                }
                else
                if (value < 0)                  // Жителей не может быть отрицательное число
                {
                    visitors = 0;
                }
                else
                {
                    visitors = value;
                }
            }
        }

        public int Quality
        {
            get { return quality; }
            set
            {

                if (value >= 9)                 // Ограничение на качество магазина
                {                               // q[0;8]
                    quality = 8;
                }
                else
                if (value < 0)
                {
                    quality = 0;
                }
                else
                {
                    quality = value;
                }
            }
        }

        public double People
        {
            get { return people; }
            set
            {

                if (value >= 99999)
                {
                    people = 99999;
                }
                else
                if (value < 0)
                {
                    people = 0;
                }
                else
                {
                    people = value;
                }
            }
        }

        public string Name
        {
            get { return name; }
            set
            {
                if (value == "")
                {
                    name = "-";
                }
                else
                    name = value;
            }
        }

        public Shop() // Конструктор без параметров
        {
            Idx = 0;
            Xc = 0;
            Yc = 0;
            People = 0;
            Quality = 0;
            Visitors = 0;
            Name="";
        }

        public Shop(int i, int xx, int yy, double pp, int qq, string s) // Конструктор с параметрами
        {
            Idx = i;
            Xc = xx;
            Yc = yy;
            People = pp;
            Quality = qq;
            Visitors = 0;
            Name = s;
        }

        public Shop MakeShop(int i, int xx, int yy, double pp, int qq, string ss)
        {
            Shop s = new Shop(i, xx, yy, pp, qq, ss);
            return s;
        }

        public override string ToString()
        {
            return Idx + " " + Xc + " " + Yc + " " + People + " " + Quality + " " + Visitors;
        }

        public static int SquareX(int x, int xS) // Квадрат разности одноименных Х координат
        {
            int x2 = 0;
            x2 = (x - xS) * (x - xS);
            return x2;
        }

        static int SquareY(int y, int yS) // Квадрат разности одноименных Y координат
        {
            int y2 = 0;
            y2 = (y - yS) * (y - yS);
            return y2;
        }

        static double T(int x, int y) // Поиск времени
        {
            double time = 0;
            time = Math.Sqrt(x + y) / 66.7;
            return time;
        }

        public static double Attr(double time, int quality) // Расчет привлекательности
        {
            double atr = 0;
            if (time != 0) atr = quality / (1 + time);
            else atr = quality;
            return atr;
        }

        static double Pr(double atr, double sum) // Расчет вероятности
        {
            double prob = 0;
            prob = atr / sum;
            return prob;
        }

        static int Cust(double p, double numberOfPeople) // Расчет количества посетителей относительно одного дома
        {
            int customers = 0;
            customers = (int)Math.Round(p * numberOfPeople);
            return customers;
        }

        int CountVisitors(Shop [] arr, int m) // Расчет количества посетителей одного магазина
        {
            int k = arr.Length;                         // Инициализация вспомогательных массивов и переменных
            double[] Time = new double[ k];
            double[] Attractiveness = new double[ k];
            double[] Probability = new double[ k];
            int [] Customers = new int [k];
            double aSum = 0;
            int cSum = 0;

                for (int j = 0; j < arr.Length; j++)      // Вычисление относительно всех зданий
                {
                    Time[j] = T(SquareX(arr[m].x*7, arr[j].x*7), SquareY(arr[m].y*7, arr[j].y*7));
                    Attractiveness[ j] = Attr(Time[j], arr[j].quality);
                    aSum = aSum + Attractiveness[ j];
                }

                for (int j = 0; j < arr.Length; j++)      // Нахождение посетителей от каждого здания
                {
                    Probability[ j] = Pr(Attractiveness[j], aSum);
                    Customers[j] = Cust(Probability[j], arr[m].people);
                    cSum = cSum + Customers[ j];
                }
                visitors = cSum;

            return visitors;
            
        }

        public static void CountVisitors(Shop[] arr)                             // Расчет количества посетителей одного магазина
        {
            int k = arr.Length;
            double[] pr = new double[k];                                         // Для общего числа вариантов, куда зохотят выйти жители домов
            double[,] Time = new double[k,k];                                    // Инициализация вспомогательных массивов и переменных
            double[,] Attractiveness = new double[k, k];
            double[,] Probability = new double[k, k];
            int[] Customers = new int[k];
            double aSum = 0;
            int house = 0;
            int[] total = new int[k];

            for (int i = 0; i < arr.Length; i++)                                 // Сколько магазинов
                if (arr[i].people != 0)
                    house++;

            Console.WriteLine(house);

            for (int i = 0; i < arr.Length; i++)                                 // Для каждого здания, магазин это или дом
            {
                for(int j = 0; j < house ; j++)                                  // От каждого дома
                {
                    if (arr[j].people != 0)
                    {
                        Time[i, j] = T(SquareX(arr[i].x * 7, arr[j].x * 7), SquareY(arr[i].y * 7, arr[j].y * 7)); // время из МАГАЗИНА до Дома

                        Attractiveness[i, j] = Attr(Time[i, j], arr[i].quality); // Привлекательность магазина для жителей каждого дома
                            
                        pr[j] = pr[j] + Attractiveness[i, j];                    // Общая привлекательность - куда могут выйти жители дома
                        
                    }
                }  
            }

            for (int i = 0; i < arr.Length; i++)                                 // Для каждого здания
            {
                arr[i].visitors = 0;
                for(int j = 0; j <house ;j++ )                                   // От каждого дома
                    if (arr[j].people != 0)
                    {
                        Probability[i, j] = Pr(Attractiveness[i, j], pr[j]);     // Вероятность, что придут именно в i магазин из j дома
                        Customers[i] = Cust(Probability[i, j], arr[j].people);   // Умножение вероятности того, что посетители из j дома придут в i магазин на количество жителей дома j
                        arr[i].visitors += Customers[i];                         // Ячейка вектора столбца при умножении - количество посетителей
                    }
            }
        } 

        public static int partition(Shop[] array, int start, int end) // Поиск опорного элемента и перестановка 
        {
            int marker = start;
            for (int i = start; i <= end; i++)
            {
                if (array[i].visitors  <= array[end].visitors)
                {
                    Shop temp = array[marker];                       // Обмен элементов
                    array[marker] = array[i];
                    array[i] = temp;
                    marker += 1;
                }
            }
            return marker - 1;
        }

        public static void quicksort(Shop[] array, int start, int end) // Сортировка
        {
            if (start >= end)
            {
                return;
            }
            int pivot = partition(array, start, end);
            quicksort(array, start, pivot - 1);
            quicksort(array, pivot + 1, end);
        }

        public static void CreateShops(ref Shop[] arr) // создание массива
        {
            int []X = new int[] { 371, 392, 392, 462, 476, 511, 532, 560, 497, 567, 602, 637, 602, 574, 588, 658, 721, 756, 805, 714, 763, 805, 854, 882, 882, 882, 826, 784, 735, 385, 441, 490, 532, 511, 560, 581, 322, 322, 322, 322, 322, 266, 245, 266, 266, 259, 210, 154, 105, 105, 133, 175, 105, 168, 126, 616, 581, 532, 602, 658, 700, 742, 770, 693, 728, 791, 882, 126, 210, 301, 119, 112, 168, 231, 119, 182, 175, 217, 224, 322, 392, 448, 392, 294, 497, 525, 588, 602, 574, 525, 455, 385, 385, 434, 469, 525, 770, 805, 861, 672, 616, 630, 581, 546, 525, 595, 679, 700, 798, 847, 896, 931, 931, 861, 735, 784, 840, 469, 532, 728, 826, 847, 679, 756, 791, 854, 854, 805, 742, 602, 595, 630, 679, 980, 1015, 1085, 1141, 1155, 1155, 882, 847, 931, 1008, 1029, 1113, 1141, 1190, 1225, 1281, 1281, 1281, 1029, 1071, 1120, 1120, 1169, 1260, 1337, 1281, 861, 546, 175, 532, 462, 497, 1001, 861, 861, 469, 938, 910, 301, 980, 938, 574, 357, 49, 21 };
            int []Y = new int[] { 455, 518, 371, 525, 525, 525, 525, 525, 378, 490, 434, 392, 364, 322, 280, 210, 280, 294, 322, 378, 371, 371, 371, 371, 392, 476, 490, 504, 448, 616, 651, 672, 728, 602, 630, 672, 609, 126, 469, 420, 385, 406, 462, 462, 504, 609, 581, 623, 623, 539, 504, 469, 420, 413, 378, 686, 721, 721, 756, 805, 861, 784, 735, 679, 651, 707, 686, 721, 721, 770, 770, 875, 861, 889, 1022, 1071, 1008, 973, 1155, 1225, 1232, 1176, 1169, 1078, 1120, 1071, 1015, 952, 882, 854, 791, 749, 840, 889, 917, 952, 1085, 1071, 1106, 1162, 1218, 1253, 1274, 1295, 1365, 1547, 1372, 1295, 1169, 1155, 1211, 1288, 1372, 1281, 1281, 1246, 1197, 1505, 1435, 1470, 1435, 1330, 1533, 1554, 1491, 1435, 1589, 1561, 1624, 1582, 1694, 1694, 1694, 896, 868, 952, 1008, 1092, 1127, 889, 1015, 1050, 1127, 1134, 1295, 1295, 1295, 1295, 1295, 1372, 1421, 1281, 1358, 1435, 1624, 1701, 1750, 1680, 1897, 805, 546, 889, 1099, 1435, 399, 1302, 1848, 1848, 1211, 1344, 1330, 350, 1505, 1344, 532, 1372, 1029, 672 };
            double [] N = new double[] { 564.3, 237.6, 356.4, 118.8, 118.8, 118.8, 118.8, 118.8, 213.84, 356.4, 213.84, 213.84, 213.84, 222.75, 222.75, 481.14, 213.84, 106.92, 213.84, 213.84, 213.84, 201.96, 103.95, 103.95, 213.84, 80.19, 231.66, 213.84, 213.84, 534.6, 534.6, 534.6, 534.6, 148.5, 148.5, 148.5, 35.64, 35.64, 178.2, 178.2, 106.92, 106.92, 207.9, 23.76, 23.76, 133.65, 65.34, 629.64, 29.7, 71.28, 166.32, 356.4, 47.52, 106.92, 106.92, 178.2, 178.2, 326.7, 237.6, 207.9, 207.9, 207.9, 207.9, 207.9, 178.2, 193.05, 611.82, 204.93, 712.8, 320.76, 564.3, 237.6, 237.6, 564.3, 528.66, 528.66, 222.75, 222.75, 475.2, 356.4, 406.89, 409.86, 406.89, 409.86, 350.46, 350.46, 350.46, 353.43, 350.46, 350.46, 297, 297, 297, 297, 297, 297, 237.6, 237.6, 534.6, 181.17, 184.14, 181.17, 127.71, 127.71, 127.71, 415.8, 89.1, 507.87, 294.03, 0, 267.3, 267.3, 267.3, 237.6, 270.27, 267.3, 267.3, 285.12, 225.72, 534.6, 543.51, 543.51, 365.31, 365.31, 237.6, 439.56, 439.56, 237.6, 721.71, 237.6, 299.97, 353.43, 353.43, 466.29, 469.26, 213.84, 299.97, 302.94, 299.97, 570.24, 986.04, 588.06, 240.57, 240.57, 106.92, 106.92, 106.92, 106.92, 308.88, 308.88, 308.88, 412.83, 412.83, 412.83, 392.04, 389.07, 389.07, 389.07, 605.88, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            int []Q = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 8, 8, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 8, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 7, 6, 0, 0, 0, 6, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 4, 0, 0, 0, 0, 0, 5, 0, 7, 0, 0, 0, 0, 5, 0, 3, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 8, 4, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 8, 6, 8, 8, 8, 7, 8, 8, 4, 4, 3, 2, 3, 4, 6, 8, 5, 4 };
            string[] Name = new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "Ива", "Карнавал", "Абрикос", "Виват", "Луна", "Магнит", "Перекресток", "Пятерочка", "Семья", "ПМ", "ИП Волк", "Гасанов", "ИП Джифаров", "ИП Казаку", "ИП Коровина", "ПМ", "Маг, Уин.5", "Мн, пушк. 55", "ПМ, Гайдар 7/1" };
            arr = new Shop[X.Length];
            for (int i = 0; i < X.Length; i++)
            {
                arr[i] = new Shop();
                arr[i] = new Shop(i + 1, X[i] / 7, Y[i] / 7, N[i], Q[i], Name[i]);
            }
            

        }

        public static void CountPeopleLeftHouse( Shop[] arr) // Расчет количества людей, которые выйдут из дома за покупками
        {
            for (int i = 0; i < arr.Length; i++) 
            {
                arr[i].Visitors = arr[i].CountVisitors(arr, i);

            }
        }

        public static Shop[] AddShop(Shop[] arr, Shop s) // Добавление магазина
        {
            Array.Resize(ref arr, arr.Length + 1);
            arr[arr.Length - 1] = s;
            return arr;
        }

        public static Shop[] DeleteShop(ref Shop[] a, int n, ref bool ok) // Удаление магазина
        {
            try
            {
                for (int i = 0; i < a.Length; i++) // Поиск элемента с нужным индексом дома
                    if (a[i].idx == n) n = i;      // Запись индекса элемента
                if (n < a.Length) // Если элемент нашелся
                {
                    Shop[] b = new Shop[a.Length - 1];
                    Array.Copy(a, 0, b, 0, n);
                    Array.Copy(a, n + 1, b, n, a.Length - n - 1);
                    ok = true;
                    return b;
                }
                else
                {
                    ok = false;
                    return a;
                }
            }
            catch (ArgumentOutOfRangeException)
            {
                ok = false;
                return a;
            }
        }

        static Shop[] Mult(double[,] atr, Shop[] people)
        {  
            //int[] c = new int[people.Length];
            for (int k = 0; k < people.Length; k++)
            {
                for (int i = 0; i < atr.GetLength(0); i++)
                    people[i].visitors += Cust(atr[i, k], people[k].people);

            }
            return people;
        }

    }
}
