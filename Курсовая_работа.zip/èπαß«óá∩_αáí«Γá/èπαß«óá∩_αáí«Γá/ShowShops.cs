﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Курсовая_работа
{
    public partial class ShowShops : Form // Просмотр результатов
    {
        public string s;

        public ShowShops()
        {
            InitializeComponent();
            Image img = Properties.Resources.citymap;
            this.BackgroundImage = new Bitmap(img);
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void ShowShops_Load(object sender, EventArgs e)
        {
            button1.Enabled = false;

            Form1 f = (Form1)this.Owner;
            bool flag = false;

            var column1 = new DataGridViewColumn();
            column1.HeaderText = "Номер магазина"; //текст в шапке
            column1.Width = 100; //ширина колонки
            column1.ReadOnly = true; //значение в этой колонке нельзя править
            column1.Name = "nn"; //текстовое имя колонки, его можно использовать вместо обращений по индексу
            //column1.Frozen = true; //флаг, что данная колонка всегда отображается на своем месте
            column1.CellTemplate = new DataGridViewTextBoxCell(); //тип нашей колонки

            var column2 = new DataGridViewColumn();
            column2.HeaderText = "X";
            column2.Name = "cx";
            column2.ReadOnly = true;
            column2.CellTemplate = new DataGridViewTextBoxCell();

            var column3 = new DataGridViewColumn();
            column3.HeaderText = "Y";
            column3.Name = "cy";
            column3.ReadOnly = true;
            column3.CellTemplate = new DataGridViewTextBoxCell();

            var column4 = new DataGridViewColumn();
            column4.HeaderText = "Количество жителей";
            column4.Name = "npeople";
            column4.ReadOnly = true;
            column4.CellTemplate = new DataGridViewTextBoxCell();

            var column5 = new DataGridViewColumn();
            column5.HeaderText = "Качество";
            column5.Name = "rating";
            column5.ReadOnly = true;
            column5.CellTemplate = new DataGridViewTextBoxCell();

            var column6 = new DataGridViewColumn();
            column6.HeaderText = "Количество посетителей";
            column6.Name = "qustomers";
            column6.ReadOnly = true;
            column6.CellTemplate = new DataGridViewTextBoxCell();

            var column7 = new DataGridViewColumn();
            column7.HeaderText = "Название магазина";
            column7.Name = "nameSh";
            column7.ReadOnly = true;
            column7.CellTemplate = new DataGridViewTextBoxCell();

            dataGridView1.Columns.Add(column1);
            dataGridView1.Columns.Add(column2);
            dataGridView1.Columns.Add(column3);
            dataGridView1.Columns.Add(column4);
            dataGridView1.Columns.Add(column5);
            dataGridView1.Columns.Add(column6);
            dataGridView1.Columns.Add(column7);

            dataGridView1.AllowUserToAddRows = false; //запрешаем пользователю самому добавлять строки

            int count = 0;

            if (f.arrOfShops.Length > 0)
            {

                if(f.all)
                {
                    for (int i = 0; i < f.arrOfShops.Length; i++)
                    {
                        dataGridView1.Rows.Add(f.arrOfShops[i].idx, f.arrOfShops[i].x, f.arrOfShops[i].y, f.arrOfShops[i].people, f.arrOfShops[i].quality, f.arrOfShops[i].visitors, f.arrOfShops[i].name);
                        count++;
                    }
                }

                else
                {
                        for (int i = 0; i < f.arrOfShops.Length; i++)
                        {
                            if (f.arrOfShops[i].visitors != 0)
                            {
                                dataGridView1.Rows.Add(f.arrOfShops[i].idx, f.arrOfShops[i].x, f.arrOfShops[i].y, f.arrOfShops[i].people, f.arrOfShops[i].quality, f.arrOfShops[i].visitors, f.arrOfShops[i].name);
                                count++;
                            }
                        }

                }


                if (count > 0)
                {

                    for (int i = 0; i < dataGridView1.Rows.Count; ++i)
                    {
                        for (int j = 0; j < dataGridView1.Columns.Count; ++j)
                        {
                            //Значения ячеек хряняться в типе object
                            //это позволяет хранить любые данные в таблице
                            object o = dataGridView1[j, i].Value;
                        }
                    }
                }
            }
            else MessageBox.Show("Информация о магазинах отсутствует");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           // s = dataGridView1.CurrentCell.Value.ToString();
           // DialogResult = DialogResult.OK;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;
            else
            {
                textBox1.Text = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();
                if (textBox1.Text.Length > 0) button1.Enabled = true;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if ((e.KeyChar <= 47 || e.KeyChar >= 58) && number != 8 && number != 44) //цифры, клавиша BackSpace и запятая а ASCII
            {
                e.Handled = true;
            }
        }
    }
}

