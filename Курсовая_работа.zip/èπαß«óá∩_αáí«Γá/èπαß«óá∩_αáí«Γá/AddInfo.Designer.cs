﻿namespace Курсовая_работа
{
    partial class AddInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.numberT = new System.Windows.Forms.TextBox();
            this.yT = new System.Windows.Forms.TextBox();
            this.xT = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.numberOfShops = new System.Windows.Forms.Label();
            this.shopsNumber = new System.Windows.Forms.TextBox();
            this.createNewList = new System.Windows.Forms.Button();
            this.idxLabel = new System.Windows.Forms.Label();
            this.idxT = new System.Windows.Forms.TextBox();
            this.nameL = new System.Windows.Forms.Label();
            this.nameT = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(144, 300);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 23);
            this.button1.TabIndex = 17;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.comboBox1.Location = new System.Drawing.Point(237, 213);
            this.comboBox1.MaxLength = 1;
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 16;
            this.comboBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.comboBox1_KeyDown);
            this.comboBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox1_KeyPress);
            // 
            // numberT
            // 
            this.numberT.Location = new System.Drawing.Point(237, 182);
            this.numberT.MaxLength = 5;
            this.numberT.Name = "numberT";
            this.numberT.Size = new System.Drawing.Size(100, 22);
            this.numberT.TabIndex = 15;
            this.numberT.KeyDown += new System.Windows.Forms.KeyEventHandler(this.numberT_KeyDown);
            this.numberT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.numberT_KeyPress);
            // 
            // yT
            // 
            this.yT.Location = new System.Drawing.Point(237, 148);
            this.yT.MaxLength = 3;
            this.yT.Name = "yT";
            this.yT.Size = new System.Drawing.Size(100, 22);
            this.yT.TabIndex = 14;
            this.yT.KeyDown += new System.Windows.Forms.KeyEventHandler(this.yT_KeyDown);
            this.yT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.yT_KeyPress);
            // 
            // xT
            // 
            this.xT.Location = new System.Drawing.Point(237, 113);
            this.xT.MaxLength = 3;
            this.xT.Name = "xT";
            this.xT.Size = new System.Drawing.Size(100, 22);
            this.xT.TabIndex = 13;
            this.xT.KeyDown += new System.Windows.Forms.KeyEventHandler(this.xT_KeyDown);
            this.xT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.xT_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 220);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 17);
            this.label4.TabIndex = 12;
            this.label4.Text = "Качество магазина";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 187);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(183, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "Количество жителей дома";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 153);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "Координата Y";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "Координата X ";
            // 
            // numberOfShops
            // 
            this.numberOfShops.AutoSize = true;
            this.numberOfShops.Location = new System.Drawing.Point(24, 38);
            this.numberOfShops.Name = "numberOfShops";
            this.numberOfShops.Size = new System.Drawing.Size(158, 17);
            this.numberOfShops.TabIndex = 18;
            this.numberOfShops.Text = "Количество магазинов";
            // 
            // shopsNumber
            // 
            this.shopsNumber.Location = new System.Drawing.Point(186, 32);
            this.shopsNumber.MaxLength = 3;
            this.shopsNumber.Name = "shopsNumber";
            this.shopsNumber.Size = new System.Drawing.Size(45, 22);
            this.shopsNumber.TabIndex = 19;
            this.shopsNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.shopsNumber_KeyDown);
            this.shopsNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.shopsNumber_KeyPress);
            // 
            // createNewList
            // 
            this.createNewList.Location = new System.Drawing.Point(237, 32);
            this.createNewList.Name = "createNewList";
            this.createNewList.Size = new System.Drawing.Size(98, 23);
            this.createNewList.TabIndex = 20;
            this.createNewList.Text = "Создать!";
            this.createNewList.UseVisualStyleBackColor = true;
            this.createNewList.Click += new System.EventHandler(this.createNewList_Click);
            // 
            // idxLabel
            // 
            this.idxLabel.AutoSize = true;
            this.idxLabel.Location = new System.Drawing.Point(24, 86);
            this.idxLabel.Name = "idxLabel";
            this.idxLabel.Size = new System.Drawing.Size(121, 17);
            this.idxLabel.TabIndex = 21;
            this.idxLabel.Text = "Индекс магазина";
            // 
            // idxT
            // 
            this.idxT.Location = new System.Drawing.Point(237, 81);
            this.idxT.Name = "idxT";
            this.idxT.Size = new System.Drawing.Size(100, 22);
            this.idxT.TabIndex = 22;
            // 
            // nameL
            // 
            this.nameL.AutoSize = true;
            this.nameL.Location = new System.Drawing.Point(24, 255);
            this.nameL.Name = "nameL";
            this.nameL.Size = new System.Drawing.Size(137, 17);
            this.nameL.TabIndex = 23;
            this.nameL.Text = "Название магазина";
            // 
            // nameT
            // 
            this.nameT.Location = new System.Drawing.Point(237, 250);
            this.nameT.MaxLength = 20;
            this.nameT.Name = "nameT";
            this.nameT.Size = new System.Drawing.Size(100, 22);
            this.nameT.TabIndex = 24;
            this.nameT.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nameT_KeyDown);
            // 
            // AddInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 369);
            this.Controls.Add(this.nameT);
            this.Controls.Add(this.nameL);
            this.Controls.Add(this.idxT);
            this.Controls.Add(this.idxLabel);
            this.Controls.Add(this.createNewList);
            this.Controls.Add(this.shopsNumber);
            this.Controls.Add(this.numberOfShops);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.numberT);
            this.Controls.Add(this.yT);
            this.Controls.Add(this.xT);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AddInfo";
            this.Text = "Добавить магазин";
            this.Load += new System.EventHandler(this.AddInfo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.ComboBox comboBox1;
        public System.Windows.Forms.TextBox numberT;
        public System.Windows.Forms.TextBox yT;
        public System.Windows.Forms.TextBox xT;
        public System.Windows.Forms.Label numberOfShops;
        public System.Windows.Forms.TextBox shopsNumber;
        public System.Windows.Forms.Button createNewList;
        public System.Windows.Forms.Label idxLabel;
        public System.Windows.Forms.TextBox idxT;
        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label nameL;
        public System.Windows.Forms.TextBox nameT;
    }
}