﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using System.Windows.Forms;
using Microsoft.Office.Core;

namespace Курсовая_работа
{
    class XlsWork
    {

        public static string [,] ArrRange(int rowStart, int columnStart, int rowEnd, int columnEnd, Excel.Worksheet ws)
        {
            rowEnd++;
            columnEnd++;
            Excel.Range range = (Excel.Range)ws.Range[ws.Cells[rowStart, columnStart], ws.Cells[rowEnd, columnEnd]]; // Читаем значения ячеек с листа
            object[,] holder = range.Value2; // Записываем значения в массив
            string[,] returnstring = new string[rowEnd - rowStart, columnEnd - columnStart]; // Работаем с массивом строк
            for (int p = 1; p <= rowEnd - rowStart; p++)
                for (int q = 1; q <= columnEnd - columnStart; q++)
                    returnstring[p - 1, q - 1] = holder[p, q].ToString(); // Переписываем значения
            return returnstring;
        }

        public static void GetCellValue(Excel.Worksheet sheet, ref Shop[]arr)
        {
            int lastRow = sheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell).Row; // Последняя заполненная строка
            string[,] mas = new string[lastRow, 4]; // Выделяем память под массив строк

            mas = ArrRange(2, 1, lastRow, 7,sheet); // Получаем данные с листа

            arr = new Shop[mas.GetLength(0)]; // Выделяем память для массива магазинов


            for (int l=0; l<lastRow-1;l++) // Заполняем массив
            {
                arr[l] = new Shop(Convert.ToInt32(mas[l, 0]), Convert.ToInt32(mas[l, 2]), Convert.ToInt32(mas[l, 3]), Convert.ToDouble(mas[l, 4]), Convert.ToInt32(mas[l, 5]), Convert.ToString(mas[l,1]));
            }

        }

        public static void CorrectArraysUsingExcel(ref Shop[] arr, string s, ref bool forbid)
        {
            Excel.Application ex = new Excel.Application();
            Excel.Workbooks wbs = null;
            Excel.Workbook xlWB;

            Excel.Worksheet xlSht;
            wbs = ex.Workbooks;

            try
            {
                xlWB = wbs.Open(s,
  Type.Missing, Type.Missing, Type.Missing, Type.Missing,
  Type.Missing, Type.Missing, Type.Missing, Type.Missing,
  Type.Missing, Type.Missing, Type.Missing, Type.Missing,
  Type.Missing, Type.Missing); //открываем файл 
                xlSht = xlWB.Worksheets["Количество посетителей"];
                GetCellValue(xlSht, ref arr);
            }
            catch(Exception)
            {
                forbid = true;
            }

            wbs.Close();
            ex.Quit();
        }

        public static void WriteRange(int rowStart, int columnStart, int rowEnd, int columnEnd, Excel.Worksheet ws, object  [,] mas) // Записываем данные из массива на лист
        {
            Excel.Range range = (Excel.Range)ws.Range[ws.Cells[rowStart, columnStart], ws.Cells[rowEnd, columnEnd]];
            range.Value2 = mas;
        }

        public static void SaveChanges(Shop[] arr, string s, ref bool ok)
        {
            Excel.Application ex = new Excel.Application();
            //Отобразить Excel
            ex.Visible = false;
            //Количество листов в рабочей книге
            ex.SheetsInNewWorkbook = 1;
            //Добавить рабочую книгу
            Excel.Workbooks wbs = ex.Workbooks;
            Excel.Workbook workBook = wbs.Add();
            //Excel.Workbook workBook = wbs.Add(Type.Missing);
            //Отключить отображение окон с сообщениями
            ex.DisplayAlerts = false;
            //Получаем первый лист документа (счет начинается с 1)
            Excel.Worksheet sheet = workBook.Worksheets.get_Item(1);

            var sh = workBook.Sheets;
            Excel.Worksheet sheetDiagram = (Excel.Worksheet)sh.Add(Type.Missing, sh[1], Type.Missing, Type.Missing);
            
            sheet.Name = "Количество посетителей"; // Задаем названия столбцов
           sheetDiagram.Name = "Диаграмма";
            sheet.Cells[1, 1] = "номер дома";
            sheet.Cells[1, 2] = "название магазина";
            sheet.Cells[1, 3] = "x";
            sheet.Cells[1, 4] = "y";
            sheet.Cells[1, 5] = "количество жителей";
            sheet.Cells[1, 6] = "качество магазина";
            sheet.Cells[1, 7] = "количество посетителей";

            object[,] mas = new object[arr.Length, 7]; // Выделяем память для массива для листа

            for (int p = 0; p < arr.Length; p++) // Заполняем
            {
                mas[p, 0] = (arr[p].idx);
                mas[p, 1] = (arr[p].name);
                mas[p, 2] = (arr[p].x);
                mas[p, 3] = (arr[p].y);
                mas[p, 4] = (arr[p].people);
                mas[p, 5] = (arr[p].quality);
                mas[p, 6] = (arr[p].visitors);
            }

            WriteRange(2, 1, arr.Length + 1, 7, sheet, mas); // Запсываем на лист

            MakeDiagram(sheetDiagram, sheet, arr); // Строим диаграмму

            try
            {
                workBook.SaveAs(s);
            }
            catch(Exception)
            {
                ok = false;
                
            }
            wbs.Close();
            ex.Quit();

        }


        public static void MakeDiagram(Excel.Worksheet sheetDiagram, Excel.Worksheet activeSheet, Shop [] arr)
        {
            string s = Convert.ToString(arr.Length + 1);
            string A = "A" + s;
            string F = "G" + s;
           
            Excel.Range rngIndx = activeSheet.get_Range($"A2:{A}"); // Фиксированные столбцы
            Excel.Range rngVis = activeSheet.get_Range($"G2:{F}");  // Индексы и посетители

            Excel.ChartObjects chartObjs = (Excel.ChartObjects)sheetDiagram.ChartObjects(); 
            Excel.ChartObject chartObj = chartObjs.Add(50, 50, 1500, 300); 

            Excel.Chart xlChart = chartObj.Chart; // Создание диаграммы

            xlChart.ChartType = Excel.XlChartType.xlColumnStacked; // Формат

            xlChart.HasTitle = true;
            xlChart.ChartTitle.Text = "Ожидаемое количество посетителей";

            xlChart.HasLegend = false;

            Excel.SeriesCollection seriesCollection = (Excel.SeriesCollection)xlChart.SeriesCollection(Type.Missing); // Коллекция всех объектов в диаграме

            Excel.Series series = seriesCollection.NewSeries(); // Новый объект в коллекции

            series.XValues = rngIndx; // Запись индексов

            series.Values = rngVis; // Запись значений диаграммы
            (xlChart.Axes(Excel.XlAxisType.xlCategory,
       Excel.XlAxisGroup.xlPrimary)).HasTitle = true;
            (xlChart.Axes(Excel.XlAxisType.xlCategory,
                Excel.XlAxisGroup.xlPrimary)).AxisTitle.Text = "Номер дома";
            

        }
    }
}
